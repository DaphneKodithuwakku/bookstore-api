package com.mycompany.bookstore;

import com.mycompany.bookstore.exceptions.GlobalExceptionMapper;
import com.mycompany.bookstore.resources.AuthorResource;
import com.mycompany.bookstore.resources.BookResource;
import com.mycompany.bookstore.resources.CartResource;
import com.mycompany.bookstore.resources.CustomerResource;
import com.mycompany.bookstore.resources.OrderResource;
import java.util.HashSet;
import java.util.Set;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import org.glassfish.jersey.jsonb.JsonBindingFeature;


@ApplicationPath("resources")
public class JAXRSConfiguration extends Application {
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new HashSet<>();
        
        // your resources
        resources.add(BookResource.class);
        resources.add(AuthorResource.class);
        resources.add(CartResource.class);
        resources.add(CustomerResource.class);
        resources.add(OrderResource.class);

        resources.add(GlobalExceptionMapper.class);
        
        resources.add(JsonBindingFeature.class);
         
        return resources;
    }
}
