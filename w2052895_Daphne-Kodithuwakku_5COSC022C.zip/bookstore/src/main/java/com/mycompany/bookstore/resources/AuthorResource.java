package com.mycompany.bookstore.resources;

import com.mycompany.bookstore.models.Author;
import com.mycompany.bookstore.models.Book;
import com.mycompany.bookstore.exceptions.AuthorNotFoundException;
import com.mycompany.bookstore.exceptions.InvalidInputException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Path("/authors")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AuthorResource {
    // existing authors storage
    public static final Map<Integer, Author> authors = new HashMap<>();
    private static int nextId = 1;

    //To share the book storage from BookResource
    private static final Map<Integer, Book> books = BookResource.books;

    @POST
    public Response createAuthor(Author author) {
        if (author.getName() == null || author.getBiography() == null) {
            throw new InvalidInputException("Invalid author data");
        }
        author.setId(nextId++);
        authors.put(author.getId(), author);
        return Response.status(Response.Status.CREATED).entity(author).build();
    }

    @GET
    public List<Author> getAllAuthors() {
        return new ArrayList<>(authors.values());
    }

    @GET
    @Path("/{id}")
    public Author getAuthorById(@PathParam("id") int id) {
        Author author = authors.get(id);
        if (author == null) {
            throw new AuthorNotFoundException("Author with ID " + id + " does not exist");
        }
        return author;
    }

    @PUT
    @Path("/{id}")
    public Author updateAuthor(@PathParam("id") int id, Author updatedAuthor) {
        Author author = authors.get(id);
        if (author == null) {
            throw new AuthorNotFoundException("Author with ID " + id + " does not exist");
        }
        if (updatedAuthor.getName() != null) author.setName(updatedAuthor.getName());
        if (updatedAuthor.getBiography() != null) author.setBiography(updatedAuthor.getBiography());
        return author;
    }

    @DELETE
    @Path("/{id}")
    public Response deleteAuthor(@PathParam("id") int id) {
        Author author = authors.remove(id);
        if (author == null) {
            throw new AuthorNotFoundException("Author with ID " + id + " does not exist");
        }
        return Response.status(Response.Status.NO_CONTENT).build();
    }

    // To list books by this author
    @GET
    @Path("/{id}/books")
    public List<Book> getBooksByAuthor(@PathParam("id") int id) {
        if (!authors.containsKey(id)) {
            throw new AuthorNotFoundException("Author with ID " + id + " does not exist");
        }
        return books.values().stream()
                    .filter(book -> book.getAuthorId() == id)
                    .collect(Collectors.toList());
    }
}
