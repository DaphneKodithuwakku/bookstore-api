package com.mycompany.bookstore.exceptions;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;

@Provider
public class GlobalExceptionMapper                         
        implements ExceptionMapper<RuntimeException> {     

    @Override                                         
    public Response toResponse(RuntimeException exception) {
        Map<String, String> errorResponse = new HashMap<>();
        errorResponse.put("error", exception.getClass().getSimpleName());

        if (exception instanceof BookNotFoundException) {
            errorResponse.put("message", "The requested book was not found in the bookstore.");
            return Response.status(Response.Status.NOT_FOUND)
                           .entity(errorResponse)
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        } else if (exception instanceof AuthorNotFoundException) {
            errorResponse.put("message", "The specified author was not found in the bookstore.");
            return Response.status(Response.Status.NOT_FOUND)
                           .entity(errorResponse)
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        } else if (exception instanceof CustomerNotFoundException) {
            errorResponse.put("message", "The specified customer was not found in the bookstore.");
            return Response.status(Response.Status.NOT_FOUND)
                           .entity(errorResponse)
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        } else if (exception instanceof CartNotFoundException) {
            errorResponse.put("message", "The requested cart was not found for this customer.");
            return Response.status(Response.Status.NOT_FOUND)
                           .entity(errorResponse)
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        } else if (exception instanceof InvalidInputException) {
            errorResponse.put("message", "Invalid input provided: " + exception.getMessage());
            return Response.status(Response.Status.BAD_REQUEST)
                           .entity(errorResponse)
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        } else if (exception instanceof OutOfStockException) {
            errorResponse.put("message", "The requested book is out of stock: " + exception.getMessage());
            return Response.status(Response.Status.CONFLICT)
                           .entity(errorResponse)
                           .type(MediaType.APPLICATION_JSON)
                           .build();
        }

        // Default fallback
        errorResponse.put("error", "InternalServerError");
        errorResponse.put("message", "An unexpected error occurred on the server.");
        return Response.status(Response.Status.INTERNAL_SERVER_ERROR)
                       .entity(errorResponse)
                       .type(MediaType.APPLICATION_JSON)
                       .build();
    }
}
