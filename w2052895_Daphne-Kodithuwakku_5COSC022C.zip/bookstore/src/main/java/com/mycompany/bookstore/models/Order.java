/*
 * Click nbts://nbts/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbts://nbts/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstore.models;

import javax.json.bind.annotation.JsonbProperty;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Order {
    private int id;
    private int customerId;
    private Map<Integer, Integer> items; // bookId -> quantity
    private double totalPrice;

    public Order() {
        this.items = new HashMap<>();
    }

    public Order(int id, int customerId, Map<Integer, Integer> items, double totalPrice) {
        this.id = id;
        this.customerId = customerId;
        this.items = items;
        this.totalPrice = totalPrice;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }
    public Map<Integer, Integer> getItems() { return items; }
    public void setItems(Map<Integer, Integer> items) { this.items = items; }
    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }

    // Custom method to transform items map into a list of OrderItem for JSON serialization
    @JsonbProperty("items")
    public List<OrderItem> getItemsForSerialization() {
        return items.entrySet().stream()
                .map(entry -> {
                    Book book = com.mycompany.bookstore.resources.BookResource.books.get(entry.getKey());
                    return new OrderItem(book, entry.getValue());
                })
                .collect(Collectors.toList());
    }

    // Static inner class to represent an item in the order
    public static class OrderItem {
        private final Book book;
        private final int quantity;

        public OrderItem(Book book, int quantity) {
            this.book = book;
            this.quantity = quantity;
        }

        @JsonbProperty("book")
        public Book getBook() {
            return book;
        }

        public int getQuantity() { return quantity; }
    }
}