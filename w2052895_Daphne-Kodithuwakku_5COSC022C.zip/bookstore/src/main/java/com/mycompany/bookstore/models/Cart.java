/*
 * Click nbts://nbts/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbts://nbts/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstore.models;

import javax.json.bind.annotation.JsonbProperty;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Cart {
    private int customerId;
    private Map<Integer, Integer> items; // bookId -> quantity

    public Cart() {
        this.items = new HashMap<>();
    }

    public Cart(int customerId) {
        this.customerId = customerId;
        this.items = new HashMap<>();
    }

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }
    public Map<Integer, Integer> getItems() { return items; }
    public void setItems(Map<Integer, Integer> items) { this.items = items; }

    // Custom method to transform items map into a list of CartItem for JSON serialization
    @JsonbProperty("items")
    public List<CartItem> getItemsForSerialization() {
        return items.entrySet().stream()
                .map(entry -> {
                    Book book = com.mycompany.bookstore.resources.BookResource.books.get(entry.getKey());
                    return new CartItem(book, entry.getValue());
                })
                .collect(Collectors.toList());
    }

    // Static inner class to represent an item in the cart
    public static class CartItem {
        private final Book book;
        private final int quantity;

        public CartItem(Book book, int quantity) {
            this.book = book;
            this.quantity = quantity;
        }

        @JsonbProperty("book")
        public Book getBook() {
            return book;
        }

        public int getQuantity() { return quantity; }
    }
}