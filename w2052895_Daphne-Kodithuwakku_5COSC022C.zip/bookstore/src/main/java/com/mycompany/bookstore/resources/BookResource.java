package com.mycompany.bookstore.resources;

import com.mycompany.bookstore.models.Book;
import com.mycompany.bookstore.exceptions.BookNotFoundException;
import com.mycompany.bookstore.exceptions.AuthorNotFoundException;
import com.mycompany.bookstore.exceptions.InvalidInputException;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * JAX-RS resource for managing books in the bookstore application.
 */
@Path("/books")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BookResource {
    private static final Logger LOGGER = LoggerFactory.getLogger(BookResource.class);
    public static final Map<Integer, Book> books = new ConcurrentHashMap<>();
    private static final AtomicInteger nextId = new AtomicInteger(1);

    /**
     * Creates a new book.
     * @param book The book to create.
     * @return Response with the created book and HTTP 201 status.
     * @throws InvalidInputException if book data is invalid.
     * @throws AuthorNotFoundException if the author ID is invalid.
     */
    @POST
    public Response createBook(Book book) {
        LOGGER.info("Creating book: {}", book);
        validateBook(book, true);
        int id = nextId.getAndIncrement();
        book.setId(id);
        books.put(id, book);
        LOGGER.info("Book created with ID: {}", id);
        return Response.status(Response.Status.CREATED).entity(book).build();
    }

    /**
     * Retrieves all books.
     * @return List of all books.
     */
    @GET
    public List<Book> getAllBooks() {
        LOGGER.info("Retrieving all books");
        return new ArrayList<>(books.values());
    }

    /**
     * Retrieves a book by ID.
     * @param id The book ID.
     * @return The book if found.
     * @throws BookNotFoundException if the book is not found.
     */
    @GET
    @Path("/{id}")
    public Book getBookById(@PathParam("id") int id) {
        LOGGER.info("Retrieving book with ID: {}", id);
        Book book = books.get(id);
        if (book == null) {
            throw new BookNotFoundException("Book with ID " + id + " does not exist");
        }
        return book;
    }

    /**
     * Updates an existing book.
     * @param id The book ID.
     * @param updatedBook The updated book data.
     * @return The updated book.
     * @throws BookNotFoundException if the book is not found.
     * @throws AuthorNotFoundException if the author ID is invalid.
     * @throws InvalidInputException if the updated data is invalid.
     */
    @PUT
    @Path("/{id}")
    public Book updateBook(@PathParam("id") int id, Book updatedBook) {
        LOGGER.info("Updating book with ID: {}", id);
        Book book = books.get(id);
        if (book == null) {
            throw new BookNotFoundException("Book with ID " + id + " does not exist");
        }
        validateBook(updatedBook, false);
        if (updatedBook.getTitle() != null) {
            book.setTitle(updatedBook.getTitle());
        }
        if (updatedBook.getAuthorId() != 0) {
            if (!AuthorResource.authors.containsKey(updatedBook.getAuthorId())) {
                throw new AuthorNotFoundException("Author with ID " + updatedBook.getAuthorId() + " does not exist");
            }
            book.setAuthorId(updatedBook.getAuthorId());
        }
        if (updatedBook.getIsbn() != null) {
            book.setIsbn(updatedBook.getIsbn());
        }
        if (updatedBook.getPublicationYear() != 0) {
            if (updatedBook.getPublicationYear() > LocalDate.now().getYear()) {
                throw new InvalidInputException("Publication year cannot be in the future");
            }
            book.setPublicationYear(updatedBook.getPublicationYear());
        }
        if (updatedBook.getPrice() > 0) {
            book.setPrice(updatedBook.getPrice());
        }
        if (updatedBook.getStock() >= 0) {
            book.setStock(updatedBook.getStock());
        }
        LOGGER.info("Book updated: {}", book);
        return book;
    }

    /**
     * Deletes a book by ID.
     * @param id The book ID.
     * @return Response with HTTP 204 status.
     * @throws BookNotFoundException if the book is not found.
     */
    @DELETE
    @Path("/{id}")
    public Response deleteBook(@PathParam("id") int id) {
        LOGGER.info("Deleting book with ID: {}", id);
        Book book = books.remove(id);
        if (book == null) {
            throw new BookNotFoundException("Book with ID " + id + " does not exist");
        }
        LOGGER.info("Book deleted with ID: {}", id);
        return Response.status(Response.Status.NO_CONTENT).build();
    }

    /**
     * Validates book data.
     * @param book The book to validate.
     * @param isCreate Whether this is a create operation (requires all fields).
     * @throws InvalidInputException if validation fails.
     * @throws AuthorNotFoundException if the author ID is invalid.
     */
    private void validateBook(Book book, boolean isCreate) {
        if (isCreate) {
            if (book.getTitle() == null || book.getTitle().trim().isEmpty()) {
                throw new InvalidInputException("Book title is required");
            }
            if (book.getIsbn() == null || book.getIsbn().trim().isEmpty()) {
                throw new InvalidInputException("Book ISBN is required");
            }
            if (book.getAuthorId() <= 0 || !AuthorResource.authors.containsKey(book.getAuthorId())) {
                throw new AuthorNotFoundException("Author with ID " + book.getAuthorId() + " does not exist");
            }
            if (book.getPublicationYear() <= 0) {
                throw new InvalidInputException("Publication year is required");
            }
            if (book.getPrice() <= 0) {
                throw new InvalidInputException("Price must be positive");
            }
            if (book.getStock() < 0) {
                throw new InvalidInputException("Stock cannot be negative");
            }
        }
        if (book.getPublicationYear() > LocalDate.now().getYear()) {
            throw new InvalidInputException("Publication year cannot be in the future");
        }
    }
}