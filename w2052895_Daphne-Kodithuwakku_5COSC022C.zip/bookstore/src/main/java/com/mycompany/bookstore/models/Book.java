/*
 * Click nbts://nbts/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbts://nbts/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstore.models;

import com.mycompany.bookstore.resources.AuthorResource;
import javax.json.bind.annotation.JsonbProperty;
import javax.json.bind.annotation.JsonbTransient;

public class Book {
    private int id;
    private String title;
    private int authorId;
    private String isbn;
    private int publicationYear;
    private double price;
    private int stock;

    public Book() {}

    public Book(int id, String title, int authorId, String isbn, int publicationYear, double price, int stock) {
        this.id = id;
        this.title = title;
        this.authorId = authorId;
        this.isbn = isbn;
        this.publicationYear = publicationYear;
        this.price = price;
        this.stock = stock;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public int getAuthorId() { return authorId; }
    public void setAuthorId(int authorId) { this.authorId = authorId; }
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    public int getPublicationYear() { return publicationYear; }
    public void setPublicationYear(int publicationYear) { this.publicationYear = publicationYear; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }

    // Exclude authorId from JSON serialization
    @JsonbTransient
    public int getAuthorIdForSerialization() { return authorId; }

    // Fetch the author's name for serialization
    @JsonbProperty("author name")
    public String getAuthorName() {
        return AuthorResource.authors.containsKey(authorId)
            ? AuthorResource.authors.get(authorId).getName()
            : "Unknown Author";
    }

    // Map publicationYear to year in the JSON response
    @JsonbProperty("year")
    public int getPublicationYearForSerialization() { return publicationYear; }

    // Exclude publicationYear from JSON serialization (since we mapped it to year)
    @JsonbTransient
    public int getPublicationYearForSerializationExclude() { return publicationYear; }

    // Add valid field (hardcoded as true since Book doesn't have this field)
    @JsonbProperty("valid")
    public boolean isValid() { return true; }
}